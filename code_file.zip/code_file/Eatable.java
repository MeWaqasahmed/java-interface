public interface Eatable {
  String chop();
  String eat();
}
