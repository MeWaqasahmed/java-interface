<classpath>
    <classpathentry kind="lib" path="libs/jcalendar-1.4.jar"/>
    <classpathentry kind="src" path="src"/>
    <classpathentry kind="output" path="bin"/>
</classpath>
